
#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// rightFront           motor         9               
// rightBack            motor         15              
// rightMid             motor         21              
// leftFront            motor         4               
// leftBack             motor         14              
// leftMid              motor         12              
// Controller1          controller                    
// Intake               motor         1               
// Inertial             inertial      5               
// MOGO                 digital_out   A               
// detected             distance      10              
// Upper                motor         20              
// mogo                 digital_out   B               
// opticalsensor        optical       3               
// aligner              distance      13              
// WallStakes           motor         17              
// rotationSensor       rotation      6               
// Doinker              digital_out   C               
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;
competition Competition;



Drive chassis(

ZERO_TRACKER_NO_ODOM,



//Left Motors:
motor_group(leftFront,leftMid,leftBack),

//Right Motors:

motor_group(rightFront, rightBack, rightMid),


PORT5,


3.25,


0.8,

//Gyro scale, this is what gyro reads when you spin the robot 360 degrees.
360,












//LF: //RF: 
PORT2, -PORT20,

//LB: //RB: 
PORT17, -PORT11,

3,
2.75,

-2,


1,

-2.75,

5.5

);






void TurnAntiClockwise(double howmuch){
 Inertial.resetRotation();
 rightFront.setVelocity(40, percent);
 rightMid.setVelocity(40, percent);
 leftFront.setVelocity(40, percent);
 leftMid.setVelocity(40, percent);
 leftBack.setVelocity(40, percent);
 rightBack.setVelocity(40, percent);
 while (true) {
 if(Inertial.rotation(degrees) > (howmuch*-1)){
 leftFront.spin(reverse);
 leftMid.spin(reverse);
 leftBack.spin(reverse);
 rightFront.spin(forward);
 rightMid.spin(forward);
 rightBack.spin(forward);
 }
 else if (Inertial.rotation(degrees) < (howmuch*-1)){
 leftFront.stop();
 leftMid.stop();
 leftBack.stop();
 rightFront.stop();
 rightMid.stop();
 rightBack.stop(); 
 return;
 }
 }
 }













































//REAL PID



// Drivetrain PID Function
void drivePID(double targetdegrees) {
  double kp = 1;
  double ki = 0.1;
  double kd = 0.1;
 double error = targetdegrees;
 double integral = 0;
 double lasterror = error;
 double speed;
 double prevdegrees = leftFront.position(degrees);

 double count = 0;

 leftFront.setPosition(0, degrees);
 leftBack.setPosition(0, degrees);
 rightFront.setPosition(0, degrees);
 rightBack.setPosition(0, degrees);
 leftMid.setPosition(0, degrees);
 rightMid.setPosition(0, degrees);
 int rspeed = 0;
 int lspeed = 0;

 while (true) {
 double measureddegrees = (leftFront.position(degrees) + rightFront.position(degrees)) / 2;
 error = targetdegrees - measureddegrees;

/*
 if (fabs(measureddegrees - prevdegrees) < 3) {
 count++; // add to count
 } else { // if not being stalled
 count = 0;
 }

 if (count > 10) { // exit when stuck for 200 ms
 leftFront.stop();
 leftBack.stop();
 rightFront.stop();
 rightBack.stop();
 leftMid.stop();
 rightMid.stop();
 Controller1.Screen.clearScreen();
 Controller1.Screen.setCursor(1, 1);
 Controller1.Screen.print("stalled");
 wait(3000,msec);
 return;
 }
*/
 // Controller1.Screen.clearScreen();
 // Controller1.Screen.setCursor(1, 1);
 // Controller1.Screen.print(measureddegrees);
 prevdegrees = measureddegrees;

 // Integral windup
 if (fabs(error) < targetdegrees/10*3 && fabs(integral) < 300) {//fabs(error) < 300
 integral += error;
 }
 if (fabs(error) < 30 /* || fl.current(amp) > 3.0*/) { // exit condition
 leftFront.stop();
 leftBack.stop();
 rightFront.stop();
 rightBack.stop();
 leftMid.stop();
 rightMid.stop();
 Controller1.Screen.clearScreen();
 Controller1.Screen.setCursor(1, 1);
 Controller1.Screen.print(error);
 wait(3000,msec);
 return;
 }

 speed = error * kp + integral * ki + (error - lasterror) * kd; // motor speed

 leftFront.spin(forward, speed, rpm);
 leftBack.spin(forward, speed, rpm);
 rightFront.spin(forward, speed, rpm);
 rightBack.spin(forward, speed, rpm);
 leftMid.spin(forward, speed, rpm);
 rightMid.spin(forward, speed, rpm);
 lasterror = error;
 wait(20, msec);
 }
}






















// Drivetrain PID Function
void IntakeCode(double targetdegrees, double kp, double ki, double kd) {
 double error = targetdegrees;
 double integral = 0;
 double lasterror = error;
 double speed;
 double prevdegrees = Upper.position(degrees);

 double count = 0;

 Upper.setPosition(0, degrees);
 
 int rspeed = 0;
 int lspeed = 0;

 while (true) {
 double measureddegrees = (Upper.position(degrees) + Upper.position(degrees)) / 2;
 error = targetdegrees - measureddegrees;

/*
 if (fabs(measureddegrees - prevdegrees) < 3) {
 count++; // add to count
 } else { // if not being stalled
 count = 0;
 }

 if (count > 10) { // exit when stuck for 200 ms
 leftFront.stop();
 leftBack.stop();
 rightFront.stop();
 rightBack.stop();
 leftMid.stop();
 rightMid.stop();
 Controller1.Screen.clearScreen();
 Controller1.Screen.setCursor(1, 1);
 Controller1.Screen.print("stalled");
 wait(3000,msec);
 return;
 }
*/
 // Controller1.Screen.clearScreen();
 // Controller1.Screen.setCursor(1, 1);
 // Controller1.Screen.print(measureddegrees);
 prevdegrees = measureddegrees;

 // Integral windup
 if (fabs(error) < targetdegrees/10*3 && fabs(integral) < 300) {//fabs(error) < 300
 integral += error;
 }
 if (fabs(error) < 30 /* || fl.current(amp) > 3.0*/) { // exit condition
 Upper.stop();

 Controller1.Screen.clearScreen();
 Controller1.Screen.setCursor(1, 1);
 Controller1.Screen.print(error);
 wait(3000,msec);
 return;
 }

 speed = error * kp + integral * ki + (error - lasterror) * kd; // motor speed

 Upper.spin(forward, speed, rpm);
 lasterror = error;
 wait(20, msec);
 }
}



void ThrowAwayBlue() {
// Controller1.rumble("...");

 if (opticalsensor.color() == cyan) {


Upper.setMaxTorque(10, percent);

wait(1000,msec);
Upper.setVelocity(100,percent);
Upper.setMaxTorque(100, percent);
}
}

void driveForward(double targetPosition) {
    // Reset the motor positions
    leftFront.resetPosition();
    leftMid.resetPosition();
    leftBack.resetPosition();
    rightFront.resetPosition();
    rightMid.resetPosition();
    rightBack.resetPosition();

            leftFront.stop(brake);
            leftMid.stop(brake);
            leftBack.stop(brake);
            rightFront.stop(brake);
            rightMid.stop(brake);
            rightBack.stop(brake);
    

    double kp = 0.7;  
    double setpoint = targetPosition; 
    double error = 0.0;
    double output = 0.0;

    double tolerance = 5.0; 
    double speedLimit = 0.5; //max speed

    while (true) {
        // Calculate the error (setpoint - current position)
        double currentPosition = (leftFront.position(degrees) + rightFront.position(degrees)) / 2; //average of dt motor positions
        error = setpoint - currentPosition;

        // Calculate P output
        output = kp * error; // P output

        // Limit output to be within -100% to 100%
        if (output > 100.0) {
            output = 100.0;
        } else if (output < -100.0) {
            output = -100.0;
        }

        // Apply the speed limit
        output *= speedLimit; // uses speed limit to stay in speed

        // Apply the output to the motors in percent
        leftFront.spin(forward, output, percent);
        leftMid.spin(forward, output, percent);
        leftBack.spin(forward, output, percent);
        rightFront.spin(forward, output, percent);
        rightMid.spin(forward, output, percent);
        rightBack.spin(forward, output, percent);
        
        // checks to see if position is less than tolerance
        if (fabs(error) < tolerance) {
            // Stop all motors
            leftFront.stop();
            leftMid.stop();
            leftBack.stop(brake);
            rightFront.stop();
            rightMid.stop();
            rightBack.stop(brake);
            vex::task::sleep(100); // wait 1/10 of a second
            break; // Exit the loop
        }

        // Wait a short time before the next loop iteration
        vex::task::sleep(20); //waits to save resources
    }
}


vex::task ColorSortRed() {
 Controller1.rumble("...");
 while(1){
 if (opticalsensor.color() == red) {
 Controller1.rumble("...");
wait(100,msec);
Upper.setVelocity(5,percent);
wait(2000,msec);
Upper.setVelocity(100,percent);
}
}
}


vex::task ColorSortBlue() {
 Controller1.rumble("...");
 wait(100,msec);
 while(1){
    wait(100,msec);
// Controller1.rumble("...");
 if (opticalsensor.color() == cyan) {

Upper.setMaxTorque(10, percent);

wait(500,msec);
Upper.setMaxTorque(100,percent);


}
}
}







void UserRedSort(){
 if (opticalsensor.color() == red) {
 Controller1.rumble("...");
wait(100,msec);
Upper.setVelocity(5,percent);
wait(2000,msec);
Upper.setVelocity(100,percent);
}
}



void UserBlueSort(){
 // Controller1.rumble("...");
if (opticalsensor.color() == cyan) {
 Controller1.rumble("...");
wait(50,msec);
Upper.setVelocity(1,percent);
wait(2500,msec);
Upper.setVelocity(100,percent);
}
}



















void TurnClockwise(double target){
 Inertial.setRotation(0,degrees);
 rightFront.setVelocity(100, percent);
 rightMid.setVelocity(100, percent);
 leftFront.setVelocity(100, percent);
 leftMid.setVelocity(100, percent);
 leftBack.setVelocity(100, percent);
 rightBack.setVelocity(100, percent);
 while (true) {
 if(Inertial.rotation(degrees) < target){
 leftFront.spin(forward);
 leftMid.spin(forward);
 leftBack.spin(forward);
 rightFront.spin(reverse); 
 rightMid.spin(reverse);
 rightBack.spin(reverse);
 }
 else if (Inertial.rotation(degrees) > target){
 leftFront.stop();
 leftMid.stop();
 leftBack.stop();
 rightFront.stop();
 rightMid.stop();
 rightBack.stop(); 
 return;
 }
 }
 }







void MogoUp(){
MOGO.set(true);
MOGO.set(true);
 }



void MogoDown(){
MOGO.set(false);
MOGO.set(false);
 }




int current_auton_selection = 0;
bool auto_started = false; 

void pre_auton(void) {
 vexcodeInit();



rotationSensor.setPosition(0, degrees);









 Controller1.rumble("...");
Inertial.calibrate();
 

while (Inertial.isCalibrating() == true){
 Controller1.rumble("...");
 wait(100,msec);
}

default_constants();
 while(auto_started == false){ 
 //Brain.Screen.clearScreen(); 
 switch(current_auton_selection){ 
 
case 0:

 Brain.Screen.printAt(50, 50, "SOLO AWP RED");
 // Brain.Screen.printAt(50, 50, "Elims Scoring Red Right");
 break;




 case 1:

 Brain.Screen.printAt(50, 50, "Elims Scoring Red Right");

 case 2:



 Brain.Screen.printAt(50, 50, "Elims Scoring Red Left");



 // Brain.Screen.printAt(50, 50, "SOLO AWP RED");
 break;

 case 3:



 Brain.Screen.printAt(50, 50, "Elims Scoring Blue Right");


 // Brain.Screen.printAt(50, 50, "Elims Scoring Red Left");
 break;

 case 4:




 Brain.Screen.printAt(50, 50, "Elims Scoring Blue Left");


 // Brain.Screen.printAt(50, 50, "Elims Scoring Blue Right");
 break;

 case 5:

 Brain.Screen.printAt(50, 50, "SOLO Awp Blue");
 break;

 case 6:

 Brain.Screen.printAt(50, 50, "Bar Touch Red Right");
 break;

 case 7:



 Brain.Screen.printAt(50, 50, "Bar Touch Red Left");
 break;

 case 8:


 Brain.Screen.printAt(50, 50, "Bar Touch Blue Left");
 break;

 case 9:


Brain.Screen.printAt(50, 50, "Bar Touch Blue Right");
 break;

 case 10:



 Brain.Screen.printAt(50, 50, "Skills");
 break;

 case 11:



 Brain.Screen.printAt(50, 50, "Skills Max");
 break;




 

 }
 if(Brain.Screen.pressing()){
 Controller1.rumble("...");
 while(Brain.Screen.pressing()) {}
 Brain.Screen.clearScreen();
 current_auton_selection ++;
 } else if (current_auton_selection == 11){
 current_auton_selection = 0;
 }
 task::sleep(10);
 }
}




void autonomous(void) {
 auto_started = true;
 switch(current_auton_selection){ 
 case 2:

Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);
mogo.set(false);
MOGO.set(false);
chassis.drive_distance(-9);
chassis.drive_distance(-4,0,12,12,1,1500,2500);

mogo.set(true);
MOGO.set(true);


chassis.turn_to_angle(270,12,1,1000,2000);
Intake.spin(forward);
Upper.spin(forward);
chassis.drive_distance(7);
chassis.drive_distance(3);
wait(1500,msec);
chassis.turn_to_angle(45);
Intake.spin(reverse);
Upper.spin(reverse);
mogo.set(false);
MOGO.set(false);
Intake.stop();
Upper.stop();
chassis.drive_distance(10);
chassis.drive_distance(5);
chassis.turn_to_angle(90);


chassis.drive_distance(7);
chassis.drive_distance(7);
chassis.drive_distance(3);
Intake.stop();
Upper.stop();


chassis.turn_to_angle(0);



chassis.drive_distance(-9);
chassis.drive_distance(-4);
chassis.drive_distance(2);
Intake.spin(forward);
Upper.spin(forward);
mogo.set(true);
MOGO.set(true);


chassis.turn_to_angle(90);
chassis.drive_distance(7);
chassis.drive_distance(3);
wait(1000,msec);


chassis.drive_distance(-8,60);
WallStakes.spin(forward);
chassis.drive_distance(-8);
chassis.drive_distance(-8);
/*
chassis.turn_to_angle(195);
chassis.drive_distance(6);
wait(2000,msec);
chassis.drive_distance(-5);
chassis.turn_to_angle(270);
chassis.drive_distance(25);





*/



/////////
 break; 

 case 1: //Elims Red Right


Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);
mogo.set(false);
MOGO.set(false);


driveForward(-400);
chassis.drive_distance(-3,0,2,2);
mogo.set(true);
MOGO.set(true);
wait(500,msec);
//chassis.turn_to_angle(270,12,1,500,1500);
chassis.turn_to_angle(270);

Intake.spin(forward);
Upper.spin(forward);

wait(750,msec);

mogo.set(false);
MOGO.set(false);
Upper.stop();

driveForward(1); //reset

driveForward(250);

driveForward(75);

chassis.turn_to_angle(0);

driveForward(-1); //reset

driveForward(-230);

mogo.set(true);
MOGO.set(true);

wait(500,msec);
Upper.spin(forward);

driveForward(1); //reset

driveForward(800);

chassis.turn_to_angle(290);

Doinker.set(true);

driveForward(1); //reset


driveForward(200);

chassis.turn_to_angle(180);

chassis.turn_to_angle(135);

Doinker.set(false);


driveForward(-1); //reset


driveForward(-200);


chassis.turn_to_angle(145);

driveForward(1); //reset

driveForward(200);

//mogo.set(false);
//MOGO.set(false);

 break;

 case 0: //Elims Red Left


Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);
mogo.set(false);
MOGO.set(false);


driveForward(-400);
chassis.drive_distance(-3,0,2,2);
mogo.set(true);
MOGO.set(true);
wait(500,msec);
chassis.turn_to_angle(90,12,1,1000,2000);

Intake.spin(forward);
Upper.spin(forward);

driveForward(1); //reset

driveForward(250);

driveForward(110);

chassis.turn_to_angle(180);

driveForward(1); //reset

driveForward(50);
chassis.drive_distance(4,180,3,3);
wait(750,msec);

driveForward(-1); //reset

driveForward(-150);

chassis.turn_to_angle(270);


driveForward(-1); //reset

driveForward(90);


chassis.turn_to_angle(180);

driveForward(1); //reset

driveForward(120);

chassis.drive_distance(4,180,3,3);

 break;
 case 3: // Elims Scoring Blue Right


Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);
mogo.set(false);
MOGO.set(false);


driveForward(-400);
chassis.drive_distance(-3,0,2,2);
mogo.set(true);
MOGO.set(true);
wait(500,msec);
chassis.turn_to_angle(270,12,1,1000,2000);

Intake.spin(forward);
Upper.spin(forward);

driveForward(1); //reset

driveForward(250);

driveForward(110);

chassis.turn_to_angle(180);

driveForward(1); //reset

driveForward(50);
chassis.drive_distance(4,180,3,3);
wait(750,msec);

driveForward(-1); //reset

driveForward(-150);

chassis.turn_to_angle(90);

driveForward(-1); //reset

driveForward(90);


chassis.turn_to_angle(180);

driveForward(1); //reset

driveForward(120);

chassis.drive_distance(4,180,3,3);


wait(10,sec);


 case 4: // Elims Auton Blue Left

Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);
mogo.set(false);
MOGO.set(false);



driveForward(-400);
chassis.drive_distance(-3,0,2,2);
mogo.set(true);
MOGO.set(true);
wait(500,msec);
//chassis.turn_to_angle(270,12,1,500,1500);
chassis.turn_to_angle(90);




Intake.spin(forward);
Upper.spin(forward);


wait(750,msec);


mogo.set(false);
MOGO.set(false);
Upper.stop();


driveForward(1); //reset


driveForward(250);


driveForward(75);


chassis.turn_to_angle(0);




driveForward(-230);


mogo.set(true);
MOGO.set(true);


wait(500,msec);
Upper.spin(forward);


driveForward(1); //reset


driveForward(800);
chassis.turn_to_angle(290);


Doinker.set(true);




 break;


 case 5: // Elims Auton Blue



 break;


 case 6: // Elims Auton Blue





 break;


 case 7: // bar touch red left

Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);

driveForward(225);
chassis.turn_to_angle(90,12,1,300,1000);


driveForward(-1);  //reset

driveForward(-80);

driveForward(1); //reset

driveForward(30);

wait(500,msec);
Upper.spin(forward);
wait(1000,msec);
Upper.spin(reverse);

driveForward(1); //reset

driveForward(100);
/*
chassis.turn_to_angle(180,12,1,300,1000);

driveForward(1); //reset

driveForward(500);


chassis.turn_to_angle(270,12,1,300,1000);


driveForward(-1); //reset

driveForward(-400);

chassis.drive_distance(-7,225);
mogo.set(true);
MOGO.set(true);

chassis.turn_to_angle(180);


wait(3000,msec);


chassis.drive_distance(-5);
//chassis.turn_to_angle(90,3,1,1000,2000);
wait(2000,msec);


leftFront.setPosition(0, degrees);
leftMid.setPosition(0, degrees);
leftBack.setPosition(0, degrees);
rightFront.setPosition(0, degrees);
rightMid.setPosition(0, degrees);
rightBack.setPosition(0, degrees);
Controller1.Screen.print(leftFront.position(degrees));
driveForward(5,20);
Controller1.Screen.clearScreen();
Controller1.Screen.print(leftFront.position(degrees));
wait(2000,msec);
//chassis.turn_to_angle(90,3,1,1000,2000);

*/

 break;

 case 8: //

Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);

Upper.spin(forward);
Intake.spin(forward);

 while (detected.objectDistance(inches)<12){
 //Controller1.rumble("...");
 WallStakes.spin(forward);
 }
  WallStakes.stop(hold);


driveForward(550);

chassis.turn_to_angle(270,6,1,1000,2000);

driveForward(1); //reset

driveForward(300);
WallStakes.setVelocity(100,percent);
WallStakes.spin(forward);
wait(100,msec);
Upper.spin(reverse,20,percent);






 break;

 case 9: // Elims Auton Blue





 break;

 case 10: // Skills

Intake.setVelocity(100,percent);
Upper.setVelocity(100,percent);

Upper.spin(forward);
wait(1000,msec);
Upper.spin(reverse);
driveForward(-30);


driveForward(1); //reset

driveForward(160);

chassis.turn_to_angle(270,12,1,300,2000);

driveForward(-1); //reset

driveForward(-350); 

chassis.drive_distance(-3,270,3,3);

mogo.set(true);
MOGO.set(true);

chassis.turn_to_angle(0,12,1,300,2000);

Intake.spin(forward);
Upper.spin(forward);

driveForward(1); //reset


driveForward(400); 

driveForward(1); //reset

driveForward(10); 


chassis.turn_to_angle(90,12,1,300,2000);

driveForward(1); //reset

driveForward(375);

chassis.turn_to_angle(180,12,1,300,2000);
driveForward(1); //reset

driveForward(500);


chassis.turn_to_angle(315,12,1,300,2000);



driveForward(-1); //reset

driveForward(-230); //position reset against corner and drops mogo

Upper.spin(reverse);

MOGO.set(false);
mogo.set(false);

chassis.turn_to_angle(315,12,1,1000,2000);

driveForward(1); //reset

driveForward(160); 


chassis.turn_to_angle(90,12,1,300,2000);
chassis.turn_to_angle(90,12,1,300,2000);


driveForward(-1); //reset

driveForward(600); 


 break;

 case 11: // Skills Max

 break;


 }
}


int down = false;







void simpleDrive(){

 
 int forwardAmount = Controller1.Axis1.position();
 int turnAmount = Controller1.Axis3.position();
 rightFront.setVelocity(100, percent);
 rightMid.setVelocity(100, percent);
 rightBack.setVelocity(100, percent);

 leftFront.setVelocity(100, percent);
 leftMid.setVelocity(100, percent);
 leftBack.setVelocity(100, percent);

 rightFront.spin(reverse,forwardAmount - turnAmount, percent);
 leftFront.spin(forward, forwardAmount + turnAmount, percent);
 leftMid.spin(forward, forwardAmount + turnAmount, percent);
 leftBack.spin(forward, forwardAmount + turnAmount, percent);
 rightMid.spin(reverse,forwardAmount - turnAmount, percent);
 rightBack.spin(reverse,forwardAmount - turnAmount, percent);
}



void DistanceCode(){
 bool AWP = false;
 if(detected.isObjectDetected()== true){
 AWP = true;
 
 }
 else if(detected.isObjectDetected()== false){
 AWP = false;
 
 }
 else{
 
 }
}








void DoinkerCode(){
 if(Controller1.ButtonUp.pressing()){
Doinker.set(true);
Controller1.rumble("...");
 
 }
 else if(Controller1.ButtonDown.pressing()){
Doinker.set(false);

 }
 else{
//Nothing happens
 }
}





void MogoCode(){
 if(Controller1.ButtonX.pressing()){
MOGO.set(true);
mogo.set(true);
 
 }
 else if(Controller1.ButtonA.pressing()){
MOGO.set(false);
mogo.set(false);
 }
 else{
//Nothing happens
 }
}





void TestAWPCode(){
 if(detected.objectDistance(inches) < 3){
 Controller1.rumble("...");

 }

 else{

 }
} 













void UpperICode(){
 Upper.setVelocity(66, percent);
 if(Controller1.ButtonR1.pressing()){
 Upper.spin(forward);
 
 }
 else if(Controller1.ButtonL2.pressing()){

 }
 else{

 
 }
}





void redirectCode(){


 if (detected.objectDistance(inches) < 3){

Upper.stop(hold);
Intake.stop(hold);

//Controller1.rumble("...");
 
 }
 else {
// Controller1.rumble("...");
 Intake.setVelocity(100, percent);
 Upper.setVelocity(100, percent);
 if(Controller1.ButtonL1.pressing()){
 Intake.spin(forward);
 Upper.spin(forward);

 //FlywheelPID(10000,10,0,0);
 
 }
 else if(Controller1.ButtonL2.pressing()){
 Intake.spin(reverse);
 Upper.spin(reverse);
 //FlywheelPID(-10000,10,0,0);

 }
 else{
 Intake.stop();
 Upper.stop();
 
 }
}

}




void positionCode(){

 WallStakes.setVelocity(20, percent);
 if(Controller1.ButtonRight.pressing()){

 while (detected.objectDistance(inches)>12){
 Controller1.rumble("...");
 WallStakes.spin(reverse);

 }
 while (detected.objectDistance(inches)<12){
 //Controller1.rumble("...");
 WallStakes.spin(forward);
 }
 while (detected.objectDistance(inches)==12){
 WallStakes.stop(hold);
 }
 }
}










void SlowCode(){

 Intake.setVelocity(100, percent);
 Upper.setVelocity(100, percent);
 if(Controller1.ButtonUp.pressing()){
 Intake.setVelocity(50, percent);
 Upper.setVelocity(50, percent);
 //Controller1.rumble("...");
 Intake.spin(forward);
 Upper.spin(forward);
 //FlywheelPID(10000,10,0,0);
 
 }
 else if(Controller1.ButtonDown.pressing()){


 //FlywheelPID(-10000,10,0,0);

 }
 else{

 
 }
}



void wallStakesCodeReal(){

 WallStakes.setVelocity(100, percent);
 if(Controller1.ButtonL1.pressing()){

 //Controller1.rumble("...");
WallStakes.spin(forward);
 //FlywheelPID(10000,10,0,0);
 
 }
 else if(Controller1.ButtonL2.pressing()){

 WallStakes.spin(reverse);


 //FlywheelPID(-10000,10,0,0);
 
 }
 else{
 WallStakes.stop(hold);

 
 }
}




void intakeCode(){

 Intake.setVelocity(100, percent);
 Upper.setVelocity(100, percent);
 if(Controller1.ButtonR1.pressing()){

 //Controller1.rumble("...");
 Intake.spin(forward);
 Upper.spin(forward);
 //FlywheelPID(10000,10,0,0);
 
 }
 else if(Controller1.ButtonR2.pressing()){

 Intake.spin(reverse);
 Upper.spin(reverse);

 //FlywheelPID(-10000,10,0,0);

 }
 else{
 Intake.stop();
Upper.stop();
 
 }
}






void WallStakesCode(){

 WallStakes.setVelocity(100, percent);

 if(Controller1.ButtonL1.pressing()){

 //Controller1.rumble("...");
 WallStakes.spin(forward);

 //FlywheelPID(10000,10,0,0);
 
 }
 else if(Controller1.ButtonL2.pressing()){

 WallStakes.spin(reverse);

 //FlywheelPID(-10000,10,0,0);

 }
 else{
 WallStakes.stop(hold);
 
 }
}


void resetCode(){

 if(Controller1.ButtonY.pressing()){

 Controller1.rumble("...");
rotationSensor.setPosition(0, degrees);
 //FlywheelPID(10000,10,0,0);
 
 }

 else{

 
 }
}






void TestCode(){
//Controller1.rumble("...");
 Intake.setVelocity(100, percent);
 Upper.setVelocity(100, percent);
 if(Controller1.ButtonUp.pressing()){

while (1){ 

 if (opticalsensor.isNearObject()){
Controller1.rumble("...");
Intake.stop(hold);
Upper.stop(hold);
mogo.set(false);
MOGO.set(false);
 Intake.spin(forward,100,percent);
 Upper.spin(forward,100,percent);
wait(300,msec);
mogo.set(true);
MOGO.set(true);
 chassis.drive_distance(8); 





 return;
 }
 else{
 Intake.spin(forward,100,percent);
 Upper.spin(forward,100,percent);

 chassis.drive_distance(3); 
 // rightFront.spin(forward);
 // rightMid.spin(forward);
 // rightBack.spin(forward);
 // leftFront.spin(forward);
 // leftMid.spin(forward);
 // leftBack.spin(forward);
 }

}






 }
 else if(Controller1.ButtonR2.pressing()){


 }
 else{
 
 }
}





void mogoOpen(){
MOGO.set(true);
mogo.set(false);


}




void testCode(){
 if(Controller1.ButtonRight.pressing()){
chassis.turn_to_angle(270);
 
 }
 else if(Controller1.ButtonR2.pressing()){
 Intake.spin(reverse);
 
 }
 else{
 Intake.stop();
 
 }
}











double drivekp = 0.07;
double driveki = 0;
double drivekd = 0;


// program that moves the robot _ degrees to
void drivePIDold(double targetdegrees, double kp, double ki, double kd) {
double error = targetdegrees;
double integral = 0;
double lasterror = error;
// tare


while (true) {
if (abs(error) < 30 && integral < 300) {
integral += error;
}
double measureddegrees = (leftFront.position(degrees) + rightFront.position(degrees)) / 2;
error = targetdegrees - measureddegrees;


// turn forward pid distance, if at target, pid should stop
leftFront.spinFor(forward, error * kp + integral * ki + (error - lasterror) * kd,
degrees);
leftMid.spinFor(forward, error * kp + integral * ki + (error - lasterror) * kd,
degrees);
leftBack.spinFor(forward, error * kp + integral * ki + (error - lasterror) * kd,
degrees);
rightFront.spinFor(forward, error * kp + integral * ki + (error - lasterror) * kd,
degrees);
rightMid.spinFor(forward, error * kp + integral * ki + (error - lasterror) * kd,
degrees);
rightBack.spinFor(forward, error * kp + integral * ki + (error - lasterror) * kd,
degrees);


if (error < 15) {
leftFront.stop();
leftMid.stop();
leftBack.stop();
rightFront.stop();
rightMid.stop();
rightBack.stop();
}


// rightdrive.move_velocity(error * kp + integral * ki +(error - lasterror)
// * kd);
lasterror = error;
wait(10, msec);
}
}











void TimerCode(){ 
 Intake.setVelocity(100, percent);
 if(Controller1.ButtonR1.pressing()){
 Intake.spin(forward);
 
 }
 else if(Controller1.ButtonR2.pressing()){
 Intake.spin(reverse);
 
 }
 else{
 Intake.stop();

 
 }
}



void TempCode(){

 if (rightMid.temperature(temperatureUnits::fahrenheit) > 130){
 Controller1.rumble("...");
 Controller1.Screen.print("STOP DRIVING!!!");
 }
 else if(rightMid.temperature(temperatureUnits::fahrenheit) < 120){
 
 }
 else{
 
 }
}
















/*---------------------------------------------------------------------------*/
/* */
/* User Control Task */
/* */
/* This task is used to control your robot during the user control phase of */
/* a VEX Competition. */
/* */
/* You must modify the code to add your own robot specific commands here. */
/*---------------------------------------------------------------------------*/


void usercontrol(void) {
 // User control code here, inside the loop

 while (1) {
 intakeCode(); 
 //TestCode();
 resetCode();
 //SlowCode();
//positionCode();
//wallStakesCodeReal();
//ThrowAwayRed();
WallStakesCode();
Controller1.Screen.clearScreen();
Controller1.Screen.setCursor(0,0);
Controller1.Screen.print(detected.objectDistance(inches));
 //ThrowAwayRed();
 //simpleDrive();
 //UserBlueSort();
 //UserBlueSort();
 positionCode();
 //redirectCode();
//ThrowAwayBlue();
 DoinkerCode();

 MogoCode();
 //TempCode();
 //intakeCode();
 // drawLogo();
 chassis.control_arcade();
 wait(20, msec); // Sleep the task for a short amount of time to
 // prevent wasted resources.
 }
}

//jj
// Main will set up the competition functions and callbacks.
//

int main() {
 // Set up callbacks for autonomous and driver control periods.
 ColorSortBlue();
 Competition.autonomous(autonomous);
 Competition.drivercontrol(usercontrol);
 // Run the pre-autonomous function.
 pre_auton();
//ColorSortBlue();
//ColorSortRed();
 // Prevent main from exiting with an infinite loop.
 while (true) {
 wait(100, msec);
 }
}
